from django import forms
from django.core import validators

class ChessForm(forms.Form):
    dst =forms.CharField(min_length=2,max_length=2, strip=True)
    src =forms.CharField(min_length=2,max_length=2, strip=True)
